import json
from pathlib import Path

REPORT_PATH = Path("/app/report.json")

EXPECTED_TOTAL_REQUESTS = 6
EXPECTED_UNIQUE_IPS = 3
EXPECTED_TOP_PATH = "/index.html"


def _load_report():
    assert REPORT_PATH.exists(), "no /app/report.json found"
    text = REPORT_PATH.read_text()
    assert text.strip(), "/app/report.json is empty"
    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        raise AssertionError(f"/app/report.json is not valid JSON: {e}")


def test_report_is_valid_json():
    """instruction.md criterion 1: /app/report.json exists and is valid JSON."""
    report = _load_report()
    assert isinstance(report, dict), "report.json must contain a JSON object"


def test_total_requests():
    """instruction.md criterion 2: total_requests matches the log's line count."""
    report = _load_report()
    assert "total_requests" in report, "missing 'total_requests' key"
    assert report["total_requests"] == EXPECTED_TOTAL_REQUESTS, (
        f"expected total_requests={EXPECTED_TOTAL_REQUESTS}, got {report.get('total_requests')!r}"
    )


def test_unique_ips():
    """instruction.md criterion 3: unique_ips matches the number of distinct client IPs."""
    report = _load_report()
    assert "unique_ips" in report, "missing 'unique_ips' key"
    assert report["unique_ips"] == EXPECTED_UNIQUE_IPS, (
        f"expected unique_ips={EXPECTED_UNIQUE_IPS}, got {report.get('unique_ips')!r}"
    )


def test_top_path():
    """instruction.md criterion 4: top_path matches the most-requested path."""
    report = _load_report()
    assert "top_path" in report, "missing 'top_path' key"
    assert report["top_path"] == EXPECTED_TOP_PATH, (
        f"expected top_path={EXPECTED_TOP_PATH!r}, got {report.get('top_path')!r}"
    )
