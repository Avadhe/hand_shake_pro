# Log Report

There is an Apache-style access log at `/app/access.log`. Write a script (in any
language available in this environment) that parses it and produces a summary
report as valid JSON at exactly this path:

    /app/report.json

The JSON object must contain these three keys:

1. `total_requests` (integer) -- the number of non-blank lines in `/app/access.log`.
2. `unique_ips` (integer) -- the number of distinct client IP addresses (the first
   whitespace-separated field of each log line).
3. `top_path` (string) -- the request path (e.g. `/index.html`) that appears most
   often across all lines, extracted from the quoted request line
   (`"METHOD /path HTTP/1.1"`). If there is a tie, report whichever of the
   tied paths appears first in the log file.

## Success criteria

Your submission is graded against these criteria, in order:

1. `/app/report.json` exists and contains valid JSON (a single JSON object).
2. `total_requests` equals the number of non-blank lines in `/app/access.log`.
3. `unique_ips` equals the number of distinct client IPs in `/app/access.log`.
4. `top_path` equals the most frequently requested path in `/app/access.log`.

No other files or output locations are checked.
